The aim this this project is to demonstrate how to make an online movie booking with PHP and SQL,
this project is a very simple, I hope someone will make this little project into a big one. 
let me know if you do and give me some feedback. 

Important note: You need to have a local server, for example wamp server

How to import code?
1. unzip the file put in into your app server directory: That is www/omb or htdocs/omb in Xammp
2. open your broswer and type,localhost/omb or search for omb in localhost display page
3. your good to go and good to improve, 
HAPPY CODING HOPE TO HERE FROM YOU
Note: You have to register first and upload some video, because there is no video 

Note: This project is free and open sources you can used in any form you like. (Your can give me a credit or no credit it upto you, its yours)

How to import database?
1. Open your phpadmin
2. Create a database with the name omb
3. Import the database that has been provided, you are good to go
4. Your need to change the db_connection.php file in includes folder, if you have password in your phpadmin

How to run?
1. Click on account
2. Down below you will see a register button, click it and register, then login then you are good to go

Admin
username: admin
password:12345
or
username: donbok
password:12345

If you have any problem contact me
Contact:

Email: donboklari@gmail.com
whatsapp phone: +919402516338