<?php
include("includes/db_connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Online Movie Booking</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="menu.css">
<style>
.container {
  position: relative;
  text-align: center;
  color: white;
}

.centered {
  position: absolute;
  width:100%;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color:white;
   background: rgb(9,28,233);
	background: linear-gradient(62deg, rgba(9,28,233,1) 0%, rgba(255,0,151,0.5746498428472951) 48%, rgba(0,228,255,1) 100%); 
opacity:.8;
	}
</style>
</head>
<body>

<?php
include("includes/menu.php");
	   $query="select * from movie where status='1'";
	  $result=mysqli_query($con,$query);
		$rows=mysqli_fetch_array($result);
		$movie_name=$rows['movie_name'];
		$movie_id=$rows['movie_id'];
		$movie_path=$rows['movie_path'];
		$movie_des=$rows['movie_des'];
	 ?>
<div class="container">
  <img src="<?php echo "admin/uploads/$movie_path"?>" alt="Snow" style="width:100%;">
  <div class="centered">
  
 <h1>Now Showing</h1>
  <h1><?php echo "$movie_name";?></h1>

  </div>
</div>

<section>
  <nav>
    <ul>
      <li><a href="#">Facebook</a></li><br>
      <li><a href="#">Instagram</a></li><br>
      <li><a href="#">Twitter</a></li>
    </ul>
  </nav>
  
  <article>
	<table>
	<tr>
	<?php
	$query1="select * from movie where status='none'";
	  $result1=mysqli_query($con,$query1);
	while($row3=mysqli_fetch_array($result1))
	{
		$moviename=$row3['movie_name'];
		$movierelease=$row3['movie_release'];
			
		?>
	<td>
	<h1><?php echo $moviename?></h1>
	<h2>Showing On: <?php echo $movierelease?></h2>
	<?php
		$sql4="select * from video_url where video_name='$moviename'";
		$result4=mysqli_query($con,$sql4);
		$row4=mysqli_fetch_array($result4);
		$video_url=$row4['video_url'];
	?>
	
	
	 <p><iframe width="420" height="250"src="https://www.youtube.com/embed/<?php echo $video_url;?>">
</iframe></p>
	</td>
	<?php
	}
	?>
	
	</tr>
	</table>
   

  </article>
</section>
<br><br><br><br><br><br>
<br><br>

<div class="footer">
  <p>&copy Online Movie Booking</p>
</div>

</body>
</html>
