﻿<?php
session_start();
session_unset(); 
session_destroy(); 
?>
<html>
<head>
<title>Online Movie Booking || Admin Login
</title>
<style>

.container1
{
	padding-left:500px;
	padding-right:500px;
	padding-top:100px;
}



.container {
  padding: 16px;
  border:double;
border-radius: 50px 0px 50px 0px;
-moz-border-radius: 50px 0px 50px 0px;
-webkit-border-radius: 50px 0px 50px 0px;
border: 1px solid #000000;

-webkit-box-shadow: 10px 10px 16px -8px rgba(0,0,0,0.75);
-moz-box-shadow: 10px 10px 16px -8px rgba(0,0,0,0.75);
box-shadow: 10px 10px 16px -8px rgba(0,0,0,0.75);

}



</style>
</head>
<body>
<div class="container1">
<center><h1>Online Movie Booking</h1></center>

    <div class="container">
	<center>	You are logout <a href="index.php"> Click here</a></center>
    </div>
  
</div>
</body>
</html>


